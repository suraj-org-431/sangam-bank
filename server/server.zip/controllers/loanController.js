import Loan from '../models/Loan.js';
import Account from '../models/Account.js';
import { createTransactionAndLedger } from '../utils/accountLedger.js';
import { successResponse, errorResponse, badRequestResponse } from '../utils/response.js';
import Config from '../models/Config.js';
import { generateRepaymentSchedule } from '../utils/loanUtils.js';
import { notify } from '../utils/notify.js';
import { calculateLoanDetails } from '../utils/calculateLoanDetails.js';
import AccountCharge from '../models/AccountCharge.js';

// ✅ Create Loan Application
export const createLoan = async (req, res) => {
    try {
        const { borrowerId, loanAmount, loanType, interestRate, tenureMonths, remarks } = req.body;

        if (!borrowerId || !loanAmount || !loanType || !interestRate || !tenureMonths) {
            return badRequestResponse(res, 400, 'All loan fields are required');
        }

        const borrower = await Account.findById(borrowerId);
        if (!borrower) return badRequestResponse(res, 404, 'Borrower not found');

        const newLoan = await Loan.create({
            borrower: borrowerId,
            loanAmount,
            loanCategory,
            paymentType,
            interestRate,
            tenureMonths,
            remarks,
            adjustments: []
        });

        borrower.hasLoan = true;
        await borrower.save();
        await notify('loan', null, newLoan?._id || null, "Loan Created", `Loan #${newLoan?._id} created`);

        return successResponse(res, 201, 'Loan application created', newLoan);
    } catch (err) {
        console.error('❌ Loan creation failed:', err);
        return errorResponse(res, 500, 'Failed to create loan', err.message);
    }
};

// ✅ Get All Loans with pagination, filter, and search
export const getAllLoans = async (req, res) => {
    try {
        const { search = '', status, page = 1, limit = 10 } = req.query;

        const query = {};
        if (status) {
            query.status = status;
        }

        if (search) {
            query.$or = [
                { 'borrowerName': { $regex: search, $options: 'i' } },
            ];
        }

        const skip = (page - 1) * limit;

        // Fetch loans
        const loans = await Loan.find(query)
            .populate('borrower', 'applicantName accountNumber loanDetails')
            .skip(skip)
            .limit(Number(limit))
            .sort({ createdAt: -1 });

        const total = await Loan.countDocuments(query);
        const totalPages = Math.ceil(total / limit);

        // Transform entries
        const entries = loans.map((loan) => {
            const loanAmount = loan.loanAmount || 0;
            const interestRate = loan.interestRate || 0;
            const tenureMonths = loan.tenureMonths || 0;
            const paymentType = loan.paymentType || 'emi'; // Default fallback to 'emi'

            const r = interestRate / 100;
            const n = tenureMonths;

            let emiAmount = null;
            let simpleInterestAmount = null;

            if (loanAmount > 0 && r > 0 && n > 0) {
                if (paymentType.toLowerCase() === 'emi') {
                    // EMI formula
                    const monthlyRate = r;
                    emiAmount = (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, n)) /
                        (Math.pow(1 + monthlyRate, n) - 1);
                } else if (['simple', 's/i', 'si'].includes(paymentType.toLowerCase())) {
                    // Simple Interest
                    const totalInterest = (loanAmount * r * n);
                    simpleInterestAmount = (loanAmount + totalInterest) / n;
                }
            }

            return {
                _id: loan._id,
                borrowerName: loan.borrower?.applicantName || 'N/A',
                accountNumber: loan.borrower?.accountNumber || 'N/A',
                amount: loanAmount,
                loanType: loan.loanType,
                paymentType,
                status: loan.status,
                emiAmount: emiAmount ? Number(emiAmount.toFixed(2)) : null,
                simpleInstallment: simpleInterestAmount ? Number(simpleInterestAmount.toFixed(2)) : null,
                remainingPrincipal: loan.borrower?.loanDetails?.disbursedAmount || 0
            };
        });

        return successResponse(res, 200, 'Loan list fetched', {
            entries,
            totalPages,
            totalCount: total,
        });
    } catch (err) {
        return errorResponse(res, 500, 'Failed to fetch loans', err.message);
    }
};

export const getLoanById = async (req, res) => {
    try {
        const { loanId } = req.params;
        const loan = await Loan.findById(loanId).populate('borrower');

        if (!loan) return badRequestResponse(res, 404, 'Loan not found');

        const loanCalculation = calculateLoanDetails({
            amount: loan.loanAmount,
            interestRate: loan.interestRate,
            tenure: loan.tenureMonths,
            paymentType: loan.paymentType // 'emi' or 's/i'
        });

        const response = {
            _id: loan._id,
            borrowerName: loan.borrower.applicantName,
            loanAmount: loan.loanAmount,
            paidAmount: loan?.borrower?.loanDetails?.totalPaidAmount,
            paymentType: loan.paymentType,
            interestRate: loan.interestRate,
            tenureMonths: loan.tenureMonths,
            status: loan.status,
            repaymentSchedule: loan.repaymentSchedule || [],
            adjustments: loan.adjustments || [],
            calculation: loanCalculation
        };

        return successResponse(res, 200, 'Loan fetched successfully', response);
    } catch (err) {
        return errorResponse(res, 500, 'Failed to fetch loan', err.message);
    }
};

export const approveLoan = async (req, res) => {
    try {
        const { loanId } = req.params;
        const config = await Config.findOne();
        const processingFee = config?.charges?.processingFee ?? 50;
        const loan = await Loan.findById(loanId).populate('borrower');

        if (!loan) return badRequestResponse(res, 404, 'Loan not found');
        if (loan.status !== 'pending') return badRequestResponse(res, 400, 'Loan cannot be approved');

        const insuranceAmount = loan.loanAmount * 0.02;
        await AccountCharge.create({
            accountId: loan.borrower._id,
            type: 'insurance',
            label: `2% Insurance charge on ${loan.borrower.accountType}`,
            amount: parseFloat(insuranceAmount.toFixed(2)),
            notes: 'Auto-charged during account creation',
            createdBy: req.user?._id || null
        });
        await AccountCharge.create({
            accountId: loan.borrower._id,
            type: 'processingFee',
            label: `₹50 Processing fee for ${loan.borrower.accountType}`,
            amount: processingFee,
            notes: 'One-time processing fee charged during account creation',
            createdBy: req.user?._id || null
        });

        loan.status = 'approved';
        await loan.save();

        // Update account.loanDetails.status
        if (loan.borrower) {
            loan.borrower.loanDetails = loan.borrower.loanDetails || {};
            loan.borrower.loanDetails.status = 'approved';

            await loan.borrower.save();
        }

        return successResponse(res, 200, 'Loan approved successfully', loan);
    } catch (err) {
        console.log(err)
        return errorResponse(res, 500, 'Loan approval failed', err.message);
    }
};

// ✅ Disburse Loan
export const disburseLoan = async (req, res) => {
    try {
        const { loanId } = req.params;
        const loan = await Loan.findById(loanId).populate('borrower');
        if (!loan) return badRequestResponse(res, 404, 'Loan not found');
        if (loan.status !== 'approved') return badRequestResponse(res, 400, 'Loan must be approved before disbursement');

        const disbursedDate = new Date();
        const borrower = loan.borrower;

        const config = await Config.findOne();

        // ✅ UPDATED: Get nested rate based on both category and type
        const interestRate = config?.loanInterestRates?.find(
            r => r.type?.toLowerCase() === loan?.loanCategory
        )?.rate || 0;
        const isSimpleInterest = loan?.paymentType === 's/i';
        const result = calculateLoanDetails({
            amount: Number(loan.loanAmount),
            interestRate,
            tenure: isSimpleInterest ? Infinity : Number(loan?.tenureMonths),
            paymentType: loan?.paymentType
        });
        // Generate schedule
        const schedule = generateRepaymentSchedule({
            amount: loan.loanAmount,
            interestRate,
            tenure: loan.tenureMonths,
            paymentType: loan?.paymentType,
            openDate: disbursedDate,
            result
        });

        // Update Borrower
        borrower.balance += loan.loanAmount;
        borrower.hasLoan = true;
        borrower.loanDetails = {
            totalLoanAmount: loan.loanAmount,
            disbursedAmount: loan.loanAmount,
            interestRate,
            tenureMonths: loan.tenureMonths,
            emiAmount: loan?.borrower?.loanDetails?.emiAmount,
            disbursedDate,
            status: 'disbursed',
            nextDueDate: schedule[0]?.dueDate,
            repaymentSchedule: schedule
        };
        await borrower.save();

        // Update Loan
        loan.status = 'disbursed';
        loan.disbursedAmount = loan.loanAmount;
        loan.disbursedDate = disbursedDate;
        loan.repaymentSchedule = schedule;
        loan.emiAmount = loan?.borrower?.loanDetails?.emiAmount;
        loan.interestRate = interestRate;
        loan.nextDueDate = schedule[0]?.dueDate;
        await loan.save();

        // Ledger entry
        await createTransactionAndLedger({
            account: borrower,
            type: 'loanDisbursed',
            amount: loan.loanAmount,
            description: `Loan Disbursed for ₹${loan.loanAmount}`,
            date: disbursedDate,
            loanId: loan._id,
            createdBy: req.user?.name || 'Loan Admin'
        });

        return successResponse(res, 200, 'Loan disbursed and schedule generated', loan);
    } catch (err) {
        console.error('❌ Loan disbursement error:', err);
        return errorResponse(res, 500, 'Loan disbursement failed', err.message);
    }
};

export const repayLoan = async (req, res) => {
    try {
        const { loanId } = req.params;
        const { amount, paymentRef, mode = 'emi', selectedInstallmentMonth } = req.body;

        const loan = await Loan.findById(loanId).populate('borrower');
        if (!loan || loan.status !== 'disbursed') {
            return badRequestResponse(res, 400, 'Loan not disbursed or not found');
        }
        const borrower = loan.borrower;
        const schedule = loan.repaymentSchedule || [];
        const today = new Date();

        const config = await Config.findOne();
        const affectsBalance = config?.fineAffectsBalance ?? true;
        const loanFineRule = config?.fineRules?.find(r => r.accountType === 'Loan');
        const graceDays = loanFineRule?.appliesAfterDays ?? config?.fineConfig?.graceDays ?? 0;
        const fixedFineAmount = loanFineRule?.fineAmount ?? 0;
        const ledgerDescription = loanFineRule?.ledgerDescription || 'Loan Fine';

        let remainingAmount = parseFloat(amount);
        const repayments = [];

        const calculateFine = (installment) => {
            const dueWithGrace = new Date(installment.dueDate);
            dueWithGrace.setDate(dueWithGrace.getDate() + graceDays);
            return today > dueWithGrace ? fixedFineAmount : 0;
        };

        const repayInstallment = (installment, maxPayable) => {
            const alreadyPaid = installment.amountPaid || 0;
            const fine = calculateFine(installment);
            const totalDue = (installment.principal || 0) + (installment.interest || 0);
            const dueRemaining = totalDue - alreadyPaid;
            const paymentNow = Math.min(dueRemaining, maxPayable);

            if (paymentNow <= 0) return 0;

            installment.amountPaid = alreadyPaid + paymentNow;
            installment.fine = fine;
            installment.paidOn = today;
            installment.paymentRef = paymentRef || `TXN-${Date.now()}`;

            if (installment.amountPaid >= totalDue) {
                installment.paid = true;
            }

            repayments.push({
                installment,
                amount: paymentNow + (affectsBalance ? fine : 0),
                fine
            });

            return paymentNow + (affectsBalance ? fine : 0);
        };

        if (mode === 'full') {
            let remainingAmount = parseFloat(amount);
            console.log(remainingAmount);

            if (borrower.balance < remainingAmount) {
                return badRequestResponse(res, 400, `Insufficient account balance. Available: ₹${borrower.balance.toFixed(2)}, Required: ₹${remainingAmount.toFixed(2)}`);
            }
            for (let installment of schedule) {
                if (installment.paid) continue;

                const fine = calculateFine(installment);
                const totalDue = (installment.principal || 0) + (installment.interest || 0);
                const totalWithFine = totalDue + (affectsBalance ? fine : 0);

                if (remainingAmount >= totalWithFine) {
                    installment.amountPaid = totalDue;
                    installment.paid = true;
                    installment.paidOn = today;
                    installment.fine = fine;
                    installment.paymentRef = paymentRef || `TXN-${Date.now()}`;

                    repayments.push({ installment, amount: totalWithFine, fine });
                    remainingAmount -= totalWithFine;
                }
                else {
                    break;
                }
            }

        } else if (mode === 'emi') {
            const nextInstallment = schedule.find(i => !i.paid);
            if (!nextInstallment) return badRequestResponse(res, 400, 'No pending EMI found');
            const paid = repayInstallment(nextInstallment, remainingAmount);
            remainingAmount -= paid;

        } else if (mode === 'custom') {
            for (let i = 0; i < schedule.length && remainingAmount > 0; i++) {
                const installment = schedule[i];
                if (installment.paid) continue;

                const fine = calculateFine(installment);
                const principal = installment.principal || 0;
                const interest = installment.interest || 0;
                const totalDue = principal + interest;
                const alreadyPaid = installment.amountPaid || 0;
                const dueRemaining = totalDue - alreadyPaid;

                const fineToApply = (alreadyPaid === 0 && affectsBalance) ? fine : 0;
                const totalWithFine = dueRemaining + fineToApply;

                const paymentNow = Math.min(remainingAmount, totalWithFine);
                const amountToPrincipalInterest = Math.min(paymentNow, dueRemaining); // exclude fine

                if (paymentNow <= 0) break;

                installment.amountPaid = alreadyPaid + amountToPrincipalInterest;
                installment.paidOn = today;
                installment.paymentRef = paymentRef || `TXN-${Date.now()}`;
                if (alreadyPaid === 0) installment.fine = fine;

                if (installment.amountPaid >= totalDue) {
                    installment.paid = true;
                }

                repayments.push({
                    installment,
                    amount: paymentNow,
                    fine: fineToApply
                });

                remainingAmount -= paymentNow;

                // Stop here if this was a **partial** payment
                if (installment.amountPaid < totalDue) break;
            }
        }


        const totalPaid = amount - remainingAmount;

        // Update Account.loanDetails
        borrower.loanDetails.totalPaidAmount = (borrower?.loanDetails?.totalPaidAmount || 0) + totalPaid;
        borrower.loanDetails.disbursedAmount = Math.max(loan.loanAmount - borrower.loanDetails.totalPaidAmount, 0);
        borrower.loanDetails.lastEMIPaidOn = today;
        borrower.loanDetails.nextDueDate = schedule.find(i => !i.paid)?.dueDate || null;
        borrower.loanDetails.repaymentSchedule = schedule;

        if (!schedule.find(i => !i.paid)) {
            borrower.loanDetails.status = 'repaid';
            borrower.loanDetails.defaultedOn = null;
            loan.status = 'repaid';
        }

        // Update Loan
        loan.repaymentSchedule = schedule;
        loan.lastEMIPaidOn = today;
        loan.nextDueDate = borrower.loanDetails.nextDueDate;

        await borrower.save();
        await loan.save();

        // Ledger entries
        for (const rep of repayments) {
            const index = schedule.indexOf(rep.installment);
            const emiLabel = `${index + 1}${getOrdinal(index + 1)} EMI`;

            const totalInstallmentDue = (rep.installment.principal || 0) + (rep.installment.interest || 0);
            const actualPaid = rep.amount - (affectsBalance ? rep.fine : 0);
            const principalRatio = (rep.installment.principal || 0) / totalInstallmentDue;
            const interestRatio = (rep.installment.interest || 0) / totalInstallmentDue;

            const principalPaid = Math.round(actualPaid * principalRatio * 100) / 100;
            const interestPaid = Math.round(actualPaid * interestRatio * 100) / 100;

            await createTransactionAndLedger({
                account: borrower,
                type: 'loanRepayment',
                amount: principalPaid,
                description: `${emiLabel} Principal Paid`,
                date: today,
                loanId: loan._id,
                createdBy: req.user?.name || 'Clerk',
                additionalTransactions: [
                    {
                        type: 'interestPayment',
                        amount: interestPaid,
                        description: `${emiLabel} Interest Paid`
                    },
                    ...(rep.fine > 0 ? [{
                        type: 'fine',
                        amount: rep.fine,
                        description: `${ledgerDescription} - ${emiLabel}`,
                        affectsBalance
                    }] : [])
                ],
            });

            await AccountCharge.create({
                accountId: borrower._id,
                type: 'interest',
                label: `Emi Interest charge on ${borrower?.accountType}`,
                amount: parseFloat(interestPaid.toFixed(2)),
                notes: `${emiLabel} Interest`,
                createdBy: req.user?._id || null
            });
        }

        return successResponse(res, 200, 'Loan repayment successful', {
            paidInstallments: repayments.length,
            totalPaid,
            remainingAmount,
            status: loan.status
        });

    } catch (err) {
        console.error('❌ Repayment failed:', err);
        return errorResponse(res, 500, 'Loan repayment failed', err.message);
    }
};

export const simpleinterestPayLoan = async (req, res) => {
    try {
        const { loanId } = req.params;
        const { paymentRef, type, interest, amount } = req.body;
        const today = new Date();
        const loan = await Loan.findById(loanId).populate('borrower');
        if (!loan || loan.status !== 'disbursed') {
            return badRequestResponse(res, 400, 'Loan not disbursed or not found');
        }
        const borrower = loan.borrower;
        if (type === 'interestOnly') {
            await AccountCharge.create({
                accountId: borrower?._id,
                type: 'loanInterest',
                label: `Simple interest Interest charge on ${borrower?.accountType}`,
                amount: parseFloat(interest.toFixed(2)),
                notes: 'Auto-charged during interest paid',
                createdBy: req.user?._id || null
            });
        }
        else {
            await AccountCharge.create({
                accountId: borrower?._id,
                type: 'loanInterest',
                label: `Simple interest Interest charge on ${borrower?.accountType}`,
                amount: parseFloat(interest.toFixed(2)),
                notes: 'Auto-charged during interest paid',
                createdBy: req.user?._id || null
            });
            await createTransactionAndLedger({
                account: borrower,
                type: 'loanRepayment',
                amount: amount,
                description: `Simple interest Principal Paid`,
                date: today,
                loanId: loan._id,
                createdBy: req.user?.name || 'Clerk',
                additionalTransactions: [],
            });
            const updatedTotalPaid = Number(borrower.loanDetails?.totalPaidAmount || 0) + Number(amount);
            const loanAmount = Number(borrower.loanDetails?.loanAmount || 0);
            const updatedLoanDetails = {
                ...borrower.loanDetails,
                totalPaidAmount: updatedTotalPaid,
                status: updatedTotalPaid >= loanAmount ? 'repaid' : 'disbursed'
            };
            borrower.loanDetails = updatedLoanDetails;
            loan.status = updatedLoanDetails.status;
            await loan.save();
            await borrower.save();

        }
        return successResponse(res, 200, 'Loan repayment successful', {
            paidMonthlyInterest: interest,
            paidPrinciple: amount,
            status: loan.status
        });
    }
    catch (err) {
        console.log(err?.message)
        return errorResponse(res, 500, 'Loan repayment failed', err.message);
    }
}

// PUT /loans/:loanId/reject
export const rejectLoan = async (req, res) => {
    try {
        const { loanId } = req.params;
        const { reason } = req.body;

        const loan = await Loan.findById(loanId).populate('borrower');
        if (!loan) return badRequestResponse(res, 404, 'Loan not found');
        if (loan.status !== 'pending') return badRequestResponse(res, 400, 'Only draft loans can be rejected');

        loan.status = 'rejected';
        loan.remarks = reason || 'Rejected without reason';
        await loan.save();

        if (loan.borrower) {
            loan.borrower.loanDetails.status = 'rejected';
            loan.borrower.loanDetails.remarks = reason;
            await loan.borrower.save();
        }

        return successResponse(res, 200, 'Loan rejected', loan);
    } catch (err) {
        return errorResponse(res, 500, 'Loan rejection failed', err.message);
    }
};

function getOrdinal(n) {
    const s = ["th", "st", "nd", "rd"],
        v = n % 100;
    return (s[(v - 20) % 10] || s[v] || s[0]);
}

