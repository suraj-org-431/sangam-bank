export const accountNumberStartFrom = {
    'recurring': 105000001,
    's/f': 105100001,
    'fixed': 105200001,
    'mis': 105300001,
    'loan': 105400001,
}